//
//  AppDelegate.h
//  LayoutApp2
//
//  Created by kun pan on 2017/12/15.
//  Copyright © 2017年 University of Liverpool. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

