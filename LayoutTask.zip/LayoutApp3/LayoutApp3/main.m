//
//  main.m
//  LayoutApp3
//
//  Created by Channe Sun on 2017/12/15.
//  Copyright © 2017年 University of Liverpool. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
