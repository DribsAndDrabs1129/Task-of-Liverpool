//
//  AddressViewController.h
//  Money
//
//  Created by Channe Sun on 2017/11/23.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddressViewController : UIViewController

@property (nonatomic, strong)UIViewController *superVC;
@property (weak, nonatomic) IBOutlet UITextField *postCodeTF;

@end
