//
//  Cost.m
//  Money
//
//  Created by Channe Sun on 2017/11/23.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import "Cost.h"

@implementation Cost

@end
