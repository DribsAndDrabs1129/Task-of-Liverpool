//
//  DateViewController.m
//  Money
//
//  Created by Channe Sun on 2017/11/23.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import "DateViewController.h"
#import "AddCostViewController.h"

@interface DateViewController ()

@end

@implementation DateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)valueChanged:(UIDatePicker *)sender {
    
}

- (IBAction)confirm:(id)sender {
    AddCostViewController *addCostVC = (AddCostViewController *)self.superVC;
    NSDateFormatter *fomatter = [[NSDateFormatter alloc] init];
    NSTimeZone *localTimeZone = [NSTimeZone localTimeZone];
    [fomatter setTimeZone:localTimeZone];
    [fomatter setDateFormat:@"yyyy-MM-dd"];
    NSString *currentDateString = [fomatter stringFromDate:self.datePicker.date];
    [addCostVC updateDate:currentDateString];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
