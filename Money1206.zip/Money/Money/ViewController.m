//
//  ViewController.m
//  Money
//
//  Created by Channe Sun on 2017/11/23.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import "ViewController.h"
#import "BillsViewController.h"
#import "Cost.h"
#import "AddCostViewController.h"
#import "MyAccountViewController.h"
#import "DataDisplayTableViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _billArrays = [NSMutableArray new];
    _incomeArrays = [NSMutableArray new];
    _expenseArrays = [NSMutableArray new];
    NSDictionary *defaultDic = [[NSDictionary alloc] initWithObjectsAndKeys:@"Default",@"name", nil];
    [_billArrays addObject:defaultDic];
}

- (void)updateData:(NSArray *)arr withName:(NSString *)billName{
    self.billNameLabel.text = billName;
    if (arr) {
        _billArrays = [NSMutableArray arrayWithArray:arr];
    }
    [self seperateIncomeAndExpense];
}

- (void)updateCost:(Cost *)addCost withName:(NSString *)billName{
    NSInteger index = -1;
    NSMutableArray *temArr = nil;
    for (NSDictionary *dic in _billArrays) {
        if ([[dic objectForKey:@"name"] isEqualToString:billName]) {
            temArr = [NSMutableArray arrayWithArray:[dic objectForKey:@"data"]];
            [temArr addObject:addCost];
            index = [_billArrays indexOfObject:dic];
            break;
        }
    }
    
    if (index > -1) {
        NSDictionary *temDic = [[NSDictionary alloc] initWithObjectsAndKeys:billName,@"name",temArr,@"data", nil];
        [_billArrays replaceObjectAtIndex:index withObject:temDic];
    }
    [self seperateIncomeAndExpense];
}

- (void)seperateIncomeAndExpense{
    CGFloat expense = 0;
    CGFloat income = 0;
    for (int i = 0; i < _billArrays.count; i++) {
        NSDictionary *dic = [_billArrays objectAtIndex:i];
        NSArray *costArr = (NSArray *)[dic objectForKey:@"data"];
        for (int j = 0; j < costArr.count; j ++) {
            Cost *cost = (Cost *)[costArr objectAtIndex:j];
            if ([cost.type isEqualToString:@"Expense"] && [cost.billName isEqualToString:self.billNameLabel.text]) {
                [_expenseArrays addObject:cost];
                expense = expense + [cost.value floatValue];
            }
            else if ([cost.type isEqualToString:@"Income"] && [cost.billName isEqualToString:self.billNameLabel.text]){
                [_incomeArrays addObject:cost];
                income = income + [cost.value floatValue];
            }
        }
    }
    self.expenseLabel.text = [NSString stringWithFormat:@"%.2f",expense];
    self.incomeLabel.text = [NSString stringWithFormat:@"%.2f",income];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"BillsViewController"]) {
        BillsViewController *billsVC = (BillsViewController *)segue.destinationViewController;
        billsVC.superVC = self;
        billsVC.billArrays = _billArrays;
    }
    else if ([segue.identifier isEqualToString:@"AddCostViewController"]){
        AddCostViewController *addCostVC = (AddCostViewController *)segue.destinationViewController;
        addCostVC.superVC = self;
        addCostVC.billName = self.billNameLabel.text;
    }
    else if ([segue.identifier isEqualToString:@"MyAccountViewController"]){
        MyAccountViewController *myAccountVC = (MyAccountViewController *)segue.destinationViewController;
        myAccountVC.superVC = self;
    }
    else if ([segue.identifier isEqualToString:@"DataDisplayTableViewController"]){
        DataDisplayTableViewController *datadisplayVC = (DataDisplayTableViewController *)segue.destinationViewController;
        datadisplayVC.superVC = self;
        NSMutableArray *temArr = nil;
        for (NSDictionary *dic in _billArrays) {
            if ([[dic objectForKey:@"name"] isEqualToString:self.billNameLabel.text]) {
                temArr = [NSMutableArray arrayWithArray:[dic objectForKey:@"data"]];
                break;
            }
        }
        datadisplayVC.billArr = temArr;
    }
}

- (IBAction)dailyExpense:(id)sender {
    [self performSegueWithIdentifier:@"BillsViewController" sender:nil];
}

- (IBAction)actionOne:(id)sender {
    
}

- (IBAction)actionTwo:(id)sender {
    [self performSegueWithIdentifier:@"DataDisplayTableViewController" sender:nil];
}

- (IBAction)actionThree:(id)sender {
    [self performSegueWithIdentifier:@"AddCostViewController" sender:nil];
}

- (IBAction)actionFour:(id)sender {
    [self performSegueWithIdentifier:@"MyAccountViewController" sender:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
