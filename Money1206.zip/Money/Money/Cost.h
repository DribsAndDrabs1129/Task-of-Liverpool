//
//  Cost.h
//  Money
//
//  Created by Channe Sun on 2017/11/23.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Cost : NSData

@property (nonatomic, strong)NSString *item;
@property (nonatomic, strong)NSString *value;
@property (nonatomic, strong)NSString *date;
@property (nonatomic, strong)NSString *address;
@property (nonatomic, strong)NSString *billName;
@property (nonatomic, strong)NSString *type;//income or expense

@end
