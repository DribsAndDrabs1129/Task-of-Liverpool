//
//  DataDisplayTableViewController.h
//  Money
//
//  Created by Channe Sun on 2017/11/28.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DataDisplayTableViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UIButton *costType;//income expense
@property (weak, nonatomic) IBOutlet UIBarButtonItem *intervalType;//month year
@property (weak, nonatomic) IBOutlet UIButton *intervalBtn;
@property (nonatomic, strong)NSMutableArray *billArr;
@property (nonatomic, strong)UIViewController *superVC;

@end
