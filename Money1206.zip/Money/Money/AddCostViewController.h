//
//  AddCostViewController.h
//  Money
//
//  Created by Channe Sun on 2017/11/23.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddCostViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *titleBtn;
@property (nonatomic, strong)UIViewController *superVC;
@property (weak, nonatomic) IBOutlet UIButton *dateBtn;
@property (weak, nonatomic) IBOutlet UIButton *addressBtn;
@property (weak, nonatomic) IBOutlet UITextField *itemTF;
@property (weak, nonatomic) IBOutlet UITextField *valueTF;
@property (nonatomic, strong)NSString *billName;

- (void)updateDate:(NSString *)date;

- (void)updateAddress:(NSString *)address;

@end
