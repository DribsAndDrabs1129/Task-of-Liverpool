//
//  PlacesViewController.swift
//  My Favourite Places
//
//  Created by zyz on 17/12/8.
//  Copyright © 2017年 iFlytek. All rights reserved.
//

import UIKit
import CoreLocation

class PlacesViewController: UITableViewController {

    @IBOutlet var table: UITableView!
    
    var currentPlace = -1
    
    var fromPlace = Dictionary<String, String>()
    
    var places = [Dictionary<String, String>()]
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        
         places = (UserDefaults.standard.array(forKey: "FavoritePlace") as? [Dictionary<String, String>]) ?? [Dictionary<String, String>()]
        
        
        print(places)
        
        if places.count == 1 && places[0].count == 0 {
            places.remove(at: 0)
            places.append(["name":"Ashton Building", "lat": "53.406566", "lon": "-2.966531"])
            
            print(places)
        }
        
       currentPlace = -1

        table.reloadData()
    }
    
    @IBAction func addClicked(_ sender: UIBarButtonItem) {
        performSegue(withIdentifier: "add to Map", sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

         navigationItem.leftBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        // Do any additional setup after loading the view.
    }
    
    func editDone() {
        self.tableView.setEditing(false, animated: false)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonSystemItem.add, target: self, action:#selector(addClicked))
    }
    
    @objc func longpress(gestureRecognizer: UIGestureRecognizer) {
        if gestureRecognizer.state == UIGestureRecognizerState.began {
            self.tableView.setEditing(true, animated: true)
            self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action:#selector(editDone))
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


extension PlacesViewController{
    
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let fromIndex = sourceIndexPath.row
        let toIndex = destinationIndexPath.row
        fromPlace = places[fromIndex]
        places[fromIndex] = places[toIndex]
        places[toIndex] = fromPlace
        print(places)
        UserDefaults.standard.set(places, forKey: "FavoritePlace")
        UserDefaults.standard.synchronize()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return places.count;
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Cell")
        if places[indexPath.row]["name"] != nil {
            cell.textLabel?.text = places[indexPath.row]["name"]
            let uilpgr = UILongPressGestureRecognizer(target: self, action:
                #selector(ViewController.longpress(gestureRecognizer:)))
            uilpgr.minimumPressDuration = 2
            cell.addGestureRecognizer(uilpgr)
        }
        return cell
        
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        currentPlace = indexPath.row
        performSegue(withIdentifier: "to Map", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "to Map" {
            if let indexP = table.indexPathForSelectedRow {
                let desController = segue.destination as! ViewController
                desController.places = places
                desController.currentPlace = currentPlace
                
            }else{
                 let desController = segue.destination as! ViewController
                desController.places = places
                desController.currentPlace = -1
            }
        }

    }
    
    // 滑动产生删除按钮
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            places.remove(at: indexPath.row)
            
            print(places)
            
            UserDefaults.standard.set(places, forKey: "FavoritePlace")
            UserDefaults.standard.synchronize()
            
        }
        tableView.deleteRows(at: [indexPath], with: .fade)
    }
}














