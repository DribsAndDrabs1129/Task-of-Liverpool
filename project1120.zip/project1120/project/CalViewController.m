//
//  CalViewController.m
//  project
//
//  Created by 孙宇洋 on 2017/11/12.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import "CalViewController.h"
#import "FoodTableViewController.h"
#import "TableViewController.h"

@interface CalViewController (){
    NSInteger foodCal;
    NSInteger exerciseCal;
    NSInteger totalCal;
}

@end

@implementation CalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    foodCal = 0;
    exerciseCal = 0;
    totalCal = 0;
    self.BMILabel.text = [NSString stringWithFormat:@"%.2f",_myBMI];
    [self setRecomend];
}

- (void)setRecomend{
    //此处根据_myBMI的值，来推荐做运动还是吃东西
    self.recomendLabel.text = @"建议吃米饭";
}

- (IBAction)jumpToFoodVC:(id)sender {
    [self performSegueWithIdentifier:@"FoodTableViewController" sender:nil];
}

- (IBAction)jumpToExercise:(id)sender {
    [self performSegueWithIdentifier:@"TableViewController" sender:nil];
}

//重写prepareForSegue方法，把CalViewController赋值给calVC,方便以后回传calorie值
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"FoodTableViewController"]) {
        FoodTableViewController *foodVC = (FoodTableViewController *)segue.destinationViewController;
        foodVC.calVC = self;
    }
    else if ([segue.identifier isEqualToString:@"TableViewController"]){
        TableViewController *exerciseVC = (TableViewController *)segue.destinationViewController;
        exerciseVC.calVC = self;
    }
}

- (void)addCalorie:(NSInteger)cal{
    foodCal = foodCal + cal;
    totalCal = totalCal + cal;
    self.totalCalorie.text = [NSString stringWithFormat:@"%ld",totalCal];
    self.foodCalorie.text = [NSString stringWithFormat:@"%ld",foodCal];
}

- (void)deleteCalorie:(NSInteger)cal{
    exerciseCal = exerciseCal + cal;
    totalCal = totalCal - cal;
    self.totalCalorie.text = [NSString stringWithFormat:@"%ld",totalCal];
    self.exerciseCalorie.text = [NSString stringWithFormat:@"%ld",exerciseCal];
}

- (void)dealloc{
    NSLog(@"delloc cal");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
