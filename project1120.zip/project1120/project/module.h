//
//  module.h
//  project
//
//  Created by 孙宇洋 on 2017/11/13.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface module : NSObject

@property (nonatomic,strong) NSString*name;
@property NSInteger kcl;

@end
