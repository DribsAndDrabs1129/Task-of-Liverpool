//
//  datamodel.h
//  project
//
//  Created by 孙宇洋 on 2017/11/13.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "module.h"

@interface datamodel : NSObject

@property (strong,nonatomic) NSMutableArray *fruit;
@property (strong,nonatomic) NSMutableArray *meat;
@property (strong,nonatomic) NSMutableArray *innerExercise;
@property (strong,nonatomic) NSMutableArray *outerExercise;

@end
