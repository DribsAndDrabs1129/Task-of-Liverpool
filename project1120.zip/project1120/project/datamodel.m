//
//  datamodel.m
//  project
//
//  Created by 孙宇洋 on 2017/11/13.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import "datamodel.h"

@implementation datamodel

- (instancetype)init
{
    self = [super init];
    if (self) {
        //fruit
        self.fruit=[NSMutableArray array];
        module*apple=[[module alloc]init];
        apple.name=@"Apple";
        apple.kcl=60;
        
        module*orange=[[module alloc]init];
        orange.name=@"Orange";
        orange.kcl=50;
        
        module*banana=[[module alloc]init];
        banana.name=@"Banana";
        banana.kcl=70;
        
        module*pear=[[module alloc]init];
        pear.name=@"Pear";
        pear.kcl=60;
        
        module*watermelon=[[module alloc]init];
        watermelon.name=@"Watermelon";
        watermelon.kcl=50;
        
        self.fruit = [[NSMutableArray alloc] initWithObjects:apple,orange,banana,pear,watermelon,nil];
        
        //meat
        self.meat=[NSMutableArray array];
        module*beef=[[module alloc]init];
        beef.name=@"Beef";
        beef.kcl=300;
        
        module*chicken=[[module alloc]init];
        chicken.name=@"Chicken";
        chicken.kcl=180;
        
        module*mutton=[[module alloc]init];
        mutton.name=@"Mutton";
        mutton.kcl=250;
        
        module*pork=[[module alloc]init];
        pork.name=@"Pork";
        pork.kcl=500;
        
        self.meat = [[NSMutableArray alloc] initWithObjects:beef,chicken,mutton,pork,nil];
        
        //outerExercise
        module*jogging=[[module alloc]init];
        jogging.name=@"Jogging";
        jogging.kcl=50;
        
        module*walk=[[module alloc]init];
        walk.name=@"Walk";
        walk.kcl=20;
        
        module*riding=[[module alloc]init];
        riding.name=@"Riding";
        riding.kcl=20;
        
        self.outerExercise = [[NSMutableArray alloc] initWithObjects:jogging,walk,riding, nil];
        
        //innerExercise
        module*basketball=[[module alloc]init];
        basketball.name=@"Basketball";
        basketball.kcl=100;
        
        module*football=[[module alloc]init];
        football.name=@"Football";
        football.kcl=120;
        
        module*badminton=[[module alloc]init];
        badminton.name=@"Badminton";
        badminton.kcl=110;
        
        module*tabletennis=[[module alloc]init];
        tabletennis.name=@"Tabletennis";
        tabletennis.kcl=80;
        
        self.innerExercise = [[NSMutableArray alloc] initWithObjects:basketball,football,badminton,tabletennis, nil];
    }
    return self;
}

@end
