//
//  ThirdTableViewController.h
//  SizeHelper
//
//  Created by Channe Sun on 2017/11/27.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdTableViewController : UITableViewController

@property (nonatomic, strong)NSString *sex;
@property (nonatomic, assign)NSInteger type;//1,2,3

@end
