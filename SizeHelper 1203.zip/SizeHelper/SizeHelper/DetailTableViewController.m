//
//  DetailTableViewController.m
//  SizeHelper
//
//  Created by Channe Sun on 2017/11/27.
//  Copyright © 2017年 University of Leeds. All rights reserved.
//

#import "DetailTableViewController.h"

@interface DetailTableViewController ()
{
    NSArray *arr1;
    NSArray *arr2;
    NSArray *arr3;
    NSArray *arr4;
}

@end

@implementation DetailTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    if ([self.sex isEqualToString:@"man"]) {
        //MAN
        if (_type == 1) {
            arr1 = @[@"CHEST\n",@"35.4\n90cm",@"37\n94cm",@"38.6\n98cm",@"40\n102cm",@"41.7\n106cm",@"43.3\n110cm",@"44.9\n114cm",@"46.4\n118cm",@"48\n122cm"];
            arr2 = @[@"WAIST\n",@"29.5\n75cm",@"31.1\n79cm",@"32.7\n83cm",@"34.3\n87cm",@"35.8\n91cm",@"37.4\n95cm",@"39\n99cm",@"40.5\n103cm",@"42.1\n107cm"];
            arr3 = @[@"HIPS\n",@"35\n89cm",@"36.6\n93cm",@"38.1\n97cm",@"40.8\n101cm",@"41.3\n105cm",@"42.9\n109cm",@"44.5\n113cm",@"46\n117cm",@"47.6\n121cm"];
            arr4 = @[@"ARM\n",@"32.6\n83cm",@"33.2\n84.5cm",@"33.8\n86cm",@"34.4\n97.5cm",@"35\n89cm",@"35.6\n90.5cm",@"36.2\n92cm",@"36.8\n93.5cm",@"37.4\n95cm"];
        }
        else if (_type == 2){
            arr1 = @[@"NECK\n",@"14\n35.6cm",@"14.5\n36.8cm",@"15\n39.1cm",@"15.5\n39.4cm",@"15.7\n40cm",@"16\n40.6cm",@"16.5\n41.9cm",@"17\n43.2cm",@"17.5\n44.4cm",@"18\n45.7cm"];
            arr2 = @[@"CHEST\n",@"35.8\n91cm",@"37\n94cm",@"38.2\n97cm",@"39.4\n100cm",@"40.5\n103cm",@"41.7\n106cm",@"42.9\n109cm",@"44\n112cm",@"45.3\n115cm",@"46.5\n118cm"];
            arr3 = @[@"WAIST\n",@"29.9\n76cm",@"31.1\n79cm",@"32.3\n82cm",@"33.5\n85cm",@"34.6\n88cm",@"35.8\n91cm",@"37\n94cm",@"38.2\n97cm",@"39.8\n100cm",@"40.6\n103cm"];
            arr4 = @[@"ARM\n",@"32.7\n83cm",@"33.1\n84.2cm",@"33.6\n85.4cm",@"34\n86.6cm",@"34.6\n87.8cm",@"35\n89cm",@"35.5\n90.2cm",@"36\n91.4cm",@"36.5\n92.6cm",@"37\n93.8cm"];
        }
        else if (_type == 3){
            arr1 = @[@"CHEST\n",@"35.4\n90cm",@"37.8\n96cm",@"40\n102cm",@"42.5\n108cm",@"44.9\n114cm",@"47.2\n120cm",@"49.6\n126cm"];
            arr2 = @[@"WAIST\n",@"29.5\n75cm",@"31.9\n81cm",@"34.3\n87cm",@"36.6\n93cm",@"39\n99cm",@"41.3\n105cm",@"43.7\n111cm"];
            arr3 = @[@"HIPS\n",@"35\n89cm",@"37.4\n95cm",@"39.8\n101cm",@"42.1\n107cm",@"44.5\n113cm",@"46.9\n119cm",@"49.2\n125cm"];
            arr4 = @[@"ARM\n",@"33.2\n84.5cm",@"33.8\n86cm",@"34.4\n87.5cm",@"35\n89cm",@"35.6\n90.5cm",@"36.2\n92cm",@"36.8\n93.5cm"];
        }
    }
    else{
        //WOMAN
        if (_type == 1) {
            arr1 = @[@"BUST\n",@"30\n76cm",@"31\n79cm",@"32\n82cm",@"33.5\n85cm",@"35\n88cm",@"36.5\n92cm",@"38\n96cm",@"40\n100cm"];
            arr2 = @[@"WAIST\n",@"23\n58cm",@"24\n61cm",@"25\n64cm",@"26\n67cm",@"27.5\n70cm",@"29\n74cm",@"31\n78cm",@"32\n82cm"];
            arr3 = @[@"HIPS\n",@"33\n83cm",@"34\n86cm",@"35\n89cm",@"36\n92cm",@"37.5\n95cm",@"39\n99cm",@"40.5\n103cm",@"42\n107cm"];
        }
        else if (_type == 2){
            arr1 = @[@"BUST\n",@"30\n76cm",@"32\n82cm",@"35\n88cm",@"37\n94cm",@"39.5\n100cm",@"42.5\n106cm",@"44\n112cm"];
            arr2 = @[@"WAIST\n",@"23\n59cm",@"25.5\n65cm",@"28.5\n71cm",@"30\n77cm",@"32.5\n83cm",@"35\n89cm",@"37.5\n95cm"];
            arr3 = @[@"HIPS\n",@"33\n84cm",@"35.5\n90cm",@"38.5\n96cm",@"40\n102cm",@"42.5\n108cm",@"45\n114cm",@"47\n120cm"];
        }
        else if (_type == 3){
            arr1 = @[@"BUST\n",@"32\n81cm",@"34\n86cm",@"36\n91cm",@"38\n96cm",@"40\n101cm"];
            arr2 = @[@"WAIST\n",@"23\n59cm",@"25\n64cm",@"27\n69cm",@"29\n74cm",@"31\n79cm"];
            arr3 = @[@"HIPS\n",@"34\n86cm",@"36\n91cm",@"38\n96cm",@"40\n101cm",@"42\n106cm"];
        }
    }
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSInteger temRow = 0;
    if (indexPath.row > 0) {
        temRow = _sizeType;
    }
    if ([_sex isEqualToString:@"man"]) {
        UILabel *label1 = [cell.contentView viewWithTag:1000];
        UILabel *label2 = [cell.contentView viewWithTag:1001];
        UILabel *label3 = [cell.contentView viewWithTag:1002];
        UILabel *label4 = [cell.contentView viewWithTag:1003];
        
        if (arr1.count > 0) {
            label1.text = arr1[temRow];
            label1.hidden = NO;
        }
        if (arr2.count > 0) {
            label2.text = arr2[temRow];
            label2.hidden = NO;
        }
        if (arr3.count > 0) {
            label3.text = arr3[temRow];
            label3.hidden = NO;
        }
        if (arr4.count > 0) {
            label4.text = arr4[temRow];
            label4.hidden = NO;
        }
    }
    else{
        UILabel *label1 = [cell.contentView viewWithTag:2000];
        UILabel *label2 = [cell.contentView viewWithTag:2001];
        UILabel *label3 = [cell.contentView viewWithTag:2002];
        if (arr1.count > 0) {
            label1.text = arr1[temRow];
            label1.hidden = NO;
        }
        if (arr2.count > 0) {
            label2.text = arr2[temRow];
            label2.hidden = NO;
        }
        if (arr3.count > 0) {
            label3.text = arr3[temRow];
            label3.hidden = NO;
        }
    }
    
    if (indexPath.row == 0) {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    else{
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
