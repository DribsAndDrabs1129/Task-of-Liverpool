//
//  SecondViewController.swift
//  quiz
//
//  Created by Kun Pan on 2017/12/12.
//  Copyright © 2017年 University of Liverpool. All rights reserved.
//

import UIKit


class SecondViewController: UIViewController {
    
    var model: ArtworksModel = ArtworksModel()

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var locationNoteLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var closeBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.closeBtn.addTarget(self, action:#selector(closeView(_:)), for: UIControlEvents.touchUpInside)

        // Do any additional setup after loading the view.
        titleLabel.text = model.title
        locationNoteLabel.text = model.locationNotes
        yearLabel.text = model.yearOfWork
        infoLabel.text = model.information
        var urlStr: NSString = NSString(format: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP327/artwork_images/%@",model.fileName!)
        urlStr = urlStr.addingPercentEscapes(using: String.Encoding.utf8.rawValue)! as NSString
        let url: NSURL = NSURL(string: urlStr as String)!
        imageView.setImageWith(url as URL)
    }

    @IBAction func closeView(_ sender: UIButton) {
        self.dismiss(animated: true) {
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
