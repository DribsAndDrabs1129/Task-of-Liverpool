//
//  ArtworksModel.swift
//  quiz
//
//  Created by Kun Pan on 2017/12/9.
//  Copyright © 2017年 University of Liverpool. All rights reserved.
//

import UIKit

class ArtworksModel: NSObject {
    var information: String?
    var artist: String?
    var fileName: String?
    var id: String?
    var lastModified: String?
    var lat: String?
    var locationNotes: String?
    var long: String?
    var title: String?
    var yearOfWork: String?
}
