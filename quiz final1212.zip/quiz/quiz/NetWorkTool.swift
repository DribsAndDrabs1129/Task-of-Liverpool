//
//  NetWorkTool.swift
//  quiz
//
//  Created by Kun Pan on 2017/12/10.
//  Copyright © 2017年 University of Liverpool. All rights reserved.
//

import UIKit
import AFNetworking

// request type
enum RequestType : String {
    case get = "get"
    case post = "post"
}

class NetWorkTool: AFHTTPSessionManager {
    static let shareInstance : NetWorkTool = {
        let tools = NetWorkTool()
        tools.responseSerializer.acceptableContentTypes?.insert("text/html")
        tools.responseSerializer.acceptableContentTypes?.insert("text/plain")
        tools.responseSerializer = AFJSONResponseSerializer()
        tools.requestSerializer.timeoutInterval = 30
        return tools
    }()
}

extension NetWorkTool {
    func request(methodType: RequestType, urlString: String, parameters: [String: AnyObject]?, finished: @escaping (_ result: Any?, _ error: Error?) -> ()) {
        
        let successCallBack = { (task: URLSessionDataTask, result: Any?) in
            finished(result, nil)
        }
        let failureCallBack = { (task: URLSessionDataTask?, error: Error) in
            finished(nil, error)
        }

        if methodType == RequestType.get {
            get(urlString, parameters: parameters, progress: nil, success: successCallBack, failure: failureCallBack)
        } else {
            post(urlString, parameters: parameters, progress: nil, success: successCallBack, failure: failureCallBack)
        }
    }
}

extension NetWorkTool {
    func artwork(finished: @escaping (_ result: Any?, _ error: Error?) -> ()) {
        let URLString = "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP327/artworksOnCampus/data.php?class=artworks&lastUpdate=2017-11-01";
        request(methodType: .post, urlString: URLString, parameters:nil) { (result, error) in
            finished(result, error)
        }
    }
}







