//
//  ArtworkTableViewCell.swift
//  quiz
//
//  Created by Kun Pan on 2017/12/9.
//  Copyright © 2017年 University of Liverpool. All rights reserved.
//

import UIKit

class ArtworkTableViewCell: UITableViewCell {
    
    @IBOutlet weak var descrption: UILabel!
    @IBOutlet weak var entranceLabel: UILabel!
    @IBOutlet weak var locationNotes: UILabel!
    @IBOutlet weak var year: UILabel!
    @IBOutlet weak var artistName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(data:ArtworksModel){
        self.descrption.text = data.information
        self.locationNotes.text = data.locationNotes
        self.artistName.text = data.artist
        self.year.text = data.yearOfWork
        self.entranceLabel.text = data.title
    }
}
