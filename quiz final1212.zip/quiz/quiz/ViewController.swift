//
//  ViewController.swift
//  quiz
//
//  Created by Kun Pan on 2017/12/9.
//  Copyright © 2017年 University of Liverpool. All rights reserved.
//

import UIKit
import MJExtension
import MapKit

let artworkTableViewCell = "ArtworkTableViewCell"
let defaultLat = 53.406561
let defaultLong = -2.966203

class ViewController: UIViewController {
    
    var tableViewDataArr : [ArtworksModel]? = [ArtworksModel]()
    var dataArray: [ArtworksModel]? = [ArtworksModel]()//all artworks
    var dataDic = NSMutableDictionary.init()//store artworks of each building
    var artWorksDic = NSMutableDictionary.init()//store title of each artworks
    
    var mainMapView: MKMapView!// map view
    var tableView: UITableView!
    
    var ScreenWidth:CGFloat!
    var ScreenHeight:CGFloat!
    
    
    //location manager
    let locationManager:CLLocationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        ScreenWidth = self.view.frame.size.width
        ScreenHeight = self.view.frame.size.height
        setMapView()
        setTableView()
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        // Do any additional setup after loading the view, typically from a nib.
        NetWorkTool.shareInstance.artwork { (data, error) in
            let dic = data as! [String : Any]
            let array:NSArray = dic["artworks"] as! NSArray
            self.objectFromArray(data: array)
            self.tableView.reloadData()
            self.addAnnotation()
        }
    }
    
    func objectFromArray(data:NSArray) {
        // turn array into objects
        for temDic in data {
            let dic:NSDictionary = temDic as! NSDictionary
            let temModel:ArtworksModel = ArtworksModel()
            temModel.information = dic["Information"] as? String
            temModel.artist = dic["artist"]as? String
            temModel.fileName = dic["fileName"]as? String
            temModel.id = dic["id"] as? String
            temModel.lastModified = dic["lastModified"]as? String
            temModel.lat = dic["lat"]as? String
            temModel.locationNotes = dic["locationNotes"]as? String
            temModel.long = dic["long"]as? String
            temModel.title = dic["title"]as? String
            temModel.yearOfWork = dic["yearOfWork"] as? String
            temModel.artist = dic["artist"]as? String
            self.sortOfArtworks(model: temModel)
            self.dataArray?.append(temModel)
            self.artWorksDic.setValue(temModel, forKey: temModel.title!)
        }
        self.tableViewDataArr = NSMutableArray.init(array: self.dataArray!) as? [ArtworksModel]
        self.cashData()
    }
    
    func sortOfArtworks(model:ArtworksModel){
        // sort of artworks by building
        let buildingName:NSString = model.locationNotes! as NSString
        var temArtWorksOfBuilding = NSMutableArray.init()
        if self.dataDic.allKeys.count == 0 {
            let artWorksOfBuilding:NSMutableArray = NSMutableArray.init()
            artWorksOfBuilding.add(model)
            temArtWorksOfBuilding = artWorksOfBuilding
        }
        else{
            if self.dataDic.object(forKey: buildingName) != nil {
                temArtWorksOfBuilding = self.dataDic.object(forKey: buildingName) as! NSMutableArray
                temArtWorksOfBuilding.add(model)
            }
            else{
                let artWorksOfBuilding:NSMutableArray = NSMutableArray.init()
                artWorksOfBuilding.add(model)
                temArtWorksOfBuilding = artWorksOfBuilding
            }
        }
        self.dataDic .setValue(temArtWorksOfBuilding, forKey: buildingName as String)
    }
    
    func setTableView() {
        tableView = UITableView.init(frame: CGRect(x: 0, y: ScreenHeight/2.0, width: ScreenWidth, height: ScreenHeight/2.0), style: .plain)
        tableView.register(UINib(nibName: "ArtworkTableViewCell", bundle: nil), forCellReuseIdentifier: artworkTableViewCell)
        tableView.estimatedRowHeight = 100
        view.addSubview(self.tableView)
    }
    
    func setMapView() {
        //set map
        self.mainMapView = MKMapView.init(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: ScreenHeight/2.0))
        self.view.addSubview(self.mainMapView)
        
        self.mainMapView.mapType = MKMapType.standard
        
        let latDelta = 0.01
        let longDelta = 0.01
        let currentLocationSpan:MKCoordinateSpan = MKCoordinateSpanMake(latDelta, longDelta)
        
        // set current location
        let center:CLLocation = CLLocation(latitude: defaultLat, longitude: defaultLong)
        let currentRegion:MKCoordinateRegion = MKCoordinateRegion(center: center.coordinate,
                                                                  span: currentLocationSpan)
        //set region
        self.mainMapView.setRegion(currentRegion, animated: true)
        self.mainMapView.delegate = self
    }
    
    func addAnnotation () {
        //create annotation and set property
        let keyArr:NSArray = self.dataDic.allKeys as NSArray
        for key in keyArr {
            let temArr:NSMutableArray = self.dataDic.object(forKey: key) as! NSMutableArray
            let temModel:ArtworksModel = temArr.object(at: 0) as! ArtworksModel
            let objectAnnotation = MKPointAnnotation()
            let temLat = (temModel.lat! as NSString).doubleValue
            let temLong = (temModel.long! as NSString).doubleValue
            objectAnnotation.coordinate = CLLocation(latitude: temLat,
                                                     longitude: temLong).coordinate
            objectAnnotation.title = temModel.locationNotes
            self.mainMapView.addAnnotation(objectAnnotation)
        }
    }
    
    func cashData () {
        // cache data into core data and synchronise
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let managedObectContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CacheModel")
        
        do {
            let fetchedResults = try managedObectContext.fetch(fetchRequest) as? [NSManagedObject]
            if let results = fetchedResults {
                for art in results as! [CacheModel] {
                    let title:String = art.value(forKey: "title") as! String
                    if let model:ArtworksModel = self.artWorksDic.object(forKey: title) as? ArtworksModel{
                        let time:String = art.value(forKey: "lastModified") as! String
                        if time !=  model.lastModified{
                            //new modified
                            let art = NSEntityDescription.insertNewObject(forEntityName: "CacheModel", into: managedObectContext)as! CacheModel
                            art.information = model.information
                            art.artist = model.artist
                            art.fileName = model.fileName
                            art.id = model.id
                            art.lastModified = model.lastModified
                            art.lat = model.lat
                            art.locationNotes = model.locationNotes
                            art.long = model.long
                            art.title = model.title
                            art.yearOfWork = model.yearOfWork
                            
                            do {
                                try managedObectContext.save()
                                print("update to core data  success")
                            }catch let error{
                                print("update to core data fail, Error:\(error)")
                            }
                        }
                        self.artWorksDic.removeObject(forKey: title)
                    }
                }
                
                //check what's left in artWorksDic
                
                let keyArr:NSArray = self.artWorksDic.allKeys as NSArray
                for key in keyArr {
                    let model:ArtworksModel = self.artWorksDic.object(forKey: key) as! ArtworksModel
                    
                    let art = NSEntityDescription.insertNewObject(forEntityName: "CacheModel", into: managedObectContext)as! CacheModel
                    
                    art.information = model.information
                    art.artist = model.artist
                    art.fileName = model.fileName
                    art.id = model.id
                    art.lastModified = model.lastModified
                    art.lat = model.lat
                    art.locationNotes = model.locationNotes
                    art.long = model.long
                    art.title = model.title
                    art.yearOfWork = model.yearOfWork
                    do {
                        try managedObectContext.save()
                        print("add to core data success")
                    }catch let error{
                        print("add to core data fail, Error:\(error)")
                    }
                }
            }
        } catch  {
            fatalError("fetch fail")
        }
    }
    
    override func willRotate(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        // surpport landscape
        if toInterfaceOrientation.isLandscape{
            //if screen is landscape
            let temW:CGFloat = ScreenHeight
            let temH:CGFloat = ScreenWidth
            self.tableView.frame = CGRect(x: temW/2.0, y: 0, width: temW/2.0, height: temH)
            self.mainMapView.frame = CGRect(x: 0, y: 0, width: temW/2.0, height: temH)
        }
        else{
            let temW:CGFloat = ScreenWidth
            let temH:CGFloat = ScreenHeight
            self.tableView.frame = CGRect(x: 0, y: temH/2.0, width: temW, height: temH/2.0)
            self.mainMapView.frame = CGRect(x: 0, y: 0, width: temW, height: temH/2.0)
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableViewDataArr?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: artworkTableViewCell, for: indexPath) as! ArtworkTableViewCell
        let cellData = tableViewDataArr?[indexPath.row]
        cell.setData(data: cellData!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let vc = SecondViewController()
        vc.model = (self.tableViewDataArr?[indexPath.row])!
        self.present(vc, animated: true) {
            
        }
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        print("select")
        //select annotation
        let title:String = ((view.annotation?.title)!)!
        if let temArr = self.dataDic.object(forKey: title as NSString) as? NSMutableArray {
            self.tableViewDataArr?.removeAll()
            self.tableViewDataArr = NSMutableArray.init(array: temArr) as? [ArtworksModel]
            self.tableView.reloadData()
        }
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        print("deselect")
        //deselect annotation
        self.tableViewDataArr?.removeAll()
        self.tableViewDataArr = NSMutableArray.init(array: self.dataArray!) as? [ArtworksModel]
        self.tableView.reloadData()
    }
}

